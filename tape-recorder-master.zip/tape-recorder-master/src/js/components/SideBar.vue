<style>

</style>
<template>
  <div>
    Sidebar
  </div>
</template>
<script>
export default {};
</script>
