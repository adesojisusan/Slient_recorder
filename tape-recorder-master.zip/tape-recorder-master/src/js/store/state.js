export default {
  currentlyAddingTrack: null,
  isRecording: false,
  showPrompt: false,
  tracks: [],
  playing: false,
};
